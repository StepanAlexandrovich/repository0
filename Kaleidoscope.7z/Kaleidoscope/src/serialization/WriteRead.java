/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package serialization;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import core.Matrix;

public class WriteRead {
    
    private String name = "points";
    private Serialization ser = new Serialization();
    private int[][]points ;
    Matrix matrix;
    
    private boolean output,input;
    
    public WriteRead(Matrix matrix){ 
        this.matrix = matrix;
        points = new int[2][matrix.length]; 
    }
    
    public void setName(String name){ this.name = name; }
    
    public void write() { output = true; }
    
    public void read()  { input  = true; }
    
    public void outputInput(){
        
        try{
            
            if(output){
                for(int i=0;i<matrix.length;i++){
                    points[0][i] = matrix.points[i].value;
                    points[1][i] = matrix.points[i].next.value;
                }
                ser.output(points,"res\\"+name+".ser");
                output = false;
            }
        
            if(input){
                points = (int[][]) ser.input("res\\"+name+".ser");
                for(int i=0;i<matrix.length;i++){
                    matrix.points[i].value = points[0][i];
                    matrix.points[i].next.value = points[1][i];
                }
                input = false;
            }  
              
        } catch (IOException ex) {
            Logger.getLogger(WriteRead.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(WriteRead.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
