/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class Drawing {
    final int width = 250,height = 250;
    
    final Objects objects = new Objects(width,height); 
    final BufferedImage image = new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
    
    // для отрисовки
    final Point[] pointsSnake  = objects.snake.matrix.points;
    final Point[] pointsApples = objects.apples.matrix.points;
    final Graphics g = image.getGraphics();
     
    public Image newDrawing(){
        //////// ЛОГИКА ////////
        objects.process();
        
        //////// ОТРИСОВКА /////
        
            // background
        g.setColor(Color.BLUE);
        g.fillRect(0,0,width,height);
        
            // apples
        for(Point point:pointsApples){
            int bright = point.value/5;
            if(bright>255){ bright = 255; }
            if(point.value >0){image.setRGB(point.x, point.y, new Color(bright,000,000).getRGB()); }
        }
        
            // snake      
        for(Point point:pointsSnake){ 
            int bright = point.value/5;
            if(bright>255){ bright = 255; }
            if(point.value >0){image.setRGB(point.x, point.y, new Color(000,bright,000).getRGB()); }
        }
        
            // result
        if(!objects.snake.life) { 
            g.setColor(Color.YELLOW);  
            g.drawString("result "+objects.snake.value,120,120);
        }
        else                    { 
            g.setColor(Color.GREEN); 
            g.drawString("result "+objects.snake.value,180,10);
        }
        
        
        return image;
    }
    
}
