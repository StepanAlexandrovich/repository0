/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package helpers;

import peak.Cycle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Methods {
    
    public int ring(int c,int min,int max){
       if(c<min)  { c = c + (max - min + 1); }
       if(c>max)  { c = c - (max - min + 1); }
       return c;  
    }
    
    public int border(int vel,int min, int max){
        if(vel>max){ vel = max; }
        if(vel<min){ vel = min; }
        return vel;
    }
    
    public void sleep(int time){
        try {
            Thread.sleep(time);
        } catch (InterruptedException ex) {
            Logger.getLogger(Cycle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
