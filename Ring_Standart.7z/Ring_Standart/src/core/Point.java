/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package core;

import helpers.Tuning;

public class Point {
    public int peek = Tuning.peek;
    public int value,difference ;
    public Point[] points = new Point[5];
    public Point up;
    
    public void connection(Point point,int index){
        points[index] = point;
    }
    
    /////////////////////////////////////////////////////////   
    public void process(){   
        difference = 0;   
        for(Point point:points){
            difference = difference + ring(point.value - value) ;
        }
       
        up.value = ring(value + difference/4); 
        if( up.value>-10 ){ up.value = up.value + 5; }
    }
    /////////////////////////////////////////////////////////
    
    //// служебные методы
    
    private int ring(int m){
        if ( m < -peek ) { m = m + (2*peek+1); }
        if ( m > +peek ) { m = m - (2*peek+1); }
        return m;
    }
    ////
}
