

package core;

import helpers.Tuning;

public class Button {
    // static
    public Matrix matrix = new Matrix(Tuning.width,Tuning.height);
    public Point[] points = matrix.twoPlane(2);
    
    public Button(){
        for(int y = 0;y<Tuning.height/2;y++){  
            matrix.pointOfAngle(Tuning.width/2+0,y,+121);
            matrix.pointOfAngle(Tuning.width/2+1,y,-121);
        }    
    }
    
    ///////////////////////////////////////
    public void process(){ 
        for(int i = 0;i<points.length;i++){
            points[i].process();
            points[i] = points[i].up;
        }    
    }
    ///////////////////////////////////////
    
}
