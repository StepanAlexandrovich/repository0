/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package helpers;
public class Tuning {
    public static int width = 121,height = 121;
    public static int panelWidth = width*5,panelHeight = height*5;
    public static int peek = 101,interval = 0;
}
