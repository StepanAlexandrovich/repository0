/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pencil;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MyFrame extends JFrame implements ActionListener{
    public JPanel panel;
    public Labyrinth labyrinth = new Labyrinth(0,0);
    
    public MyFrame(){
        super("Pencil");
        super.setBackground(Color.GRAY);
        this.setVisible(true);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.add(panel = new Panel());
        
        new Timer(15,this).start();
    }
    
    public static void main(String[] args) {
        new MyFrame();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        labyrinth.process();
        panel.repaint();
    }

    private class Panel extends JPanel{
        @Override
        public void paint(Graphics g){
            new Robot(g,labyrinth.pointStart);
            snake((Graphics2D)g);
        }
    }
    
    void snake(Graphics2D g2D){
        g2D.setColor(Color.BLUE);
        g2D.setStroke(new BasicStroke(6.0f));
        Point point = labyrinth.point; 
        for(int i = 0;i<5;i++){
            g2D.drawLine(point.x*10+2+7,point.y*10+2+7,point.behind.x*10+2+7,point.behind.y*10+2+7);
            point = point.behind;
        }
    }
        
}
