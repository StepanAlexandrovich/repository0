/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

import java.util.Random;

class Apples {
    public  final Matrix matrix;
    private final Random random = new Random();
    
    private int time;

    Apples(int width,int height) {
        matrix = new Matrix(width,height).twoPlanes();
    }

    void process() {   
        matrix.process();
        if(++time>30){
            time = 0;
            matrix.getPoint(random.nextInt(matrix.width - 1), random.nextInt(matrix.height) - 1).value = 100000;   
        }
    }

}
