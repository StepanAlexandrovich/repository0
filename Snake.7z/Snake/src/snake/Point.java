/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

public class Point {
    public int x,y;
    public Point[] points = new Point[5];
    public Point next;
    // objects
    public int value;
    
    public void process(){
        next.value = 0;
        for(Point point:points){ 
            next.value += point.value/5;
        } 
        
        if(value>0){ value--; }
    }
    
}
