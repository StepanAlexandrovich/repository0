/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package serialization;

import helpers.Tuning;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import peak.Cycle;

public class WriteRead {
    
    private String name = "points";
    private Serialization ser = new Serialization();
    private Cycle cycle ;
    private int[]points = new int[Tuning.width*Tuning.height];
    
    private boolean output,input;
    
    public WriteRead(Cycle cycle){ this.cycle = cycle; }
    
    public void outputInput(){
        
        try{
            
          if(output){
              for(int i=0;i<points.length;i++){
                  points[i] = cycle.button.points[i].value;
              }
              ser.output(points,"res\\"+name+".ser");
              output = false;
          }
        
          if(input){
              points = (int[]) ser.input("res\\"+name+".ser");
              for(int i=0;i<points.length;i++){
                  cycle.button.points[i].value = points[i];
              }
              input = false;
          }  
              
       
        }catch (InterruptedException ex) {
            Logger.getLogger(Cycle.class.getName()).log(Level.SEVERE, null, ex);
        }catch(FileNotFoundException ex){
            System.out.println("Файл не найден ");
            System.out.println("Программа работает по умолчанию");
            input = false;
        } catch (Exception ex) {
            Logger.getLogger(Cycle.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void setName(String name){ this.name = name; }
    
    public void write() { output = true; }
    
    public void read()  { input  = true; }
    
}
