/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion_3;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MyFrame extends JFrame implements ActionListener{
    JPanel panel = new Panel();
    int i;
    
    public MyFrame(){
        super("Window");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600,1200);
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
        add(panel); 
        new Timer(0,this).start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        panel.repaint();
    }
    
    class Panel extends JPanel{
        @Override
        public void paint(Graphics g){
            // 8200
            if(++i<200){
                g.setColor(Color.BLUE);
                g.fillRect(0,0,1600,1200);
                g.setColor(Color.BLACK);
                new Drawing(g,i);
            }
        }
    }
    
    public static void main(String[] args) {
        new MyFrame();
    }
    
}
