
// для проверок
//g.setColor(new Color(0,250,0));
//g.fillRect(0,0,this.getWidth(),this.getHeight());   

package gui;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import core.Button;
import core.Point;
import helpers.Tuning;

public class Panel extends JPanel{
    public Point[] points;
    public int stepWidth  = Tuning.panelWidth /Tuning.width;
    public int stepHeight = Tuning.panelHeight/Tuning.height;
    
    
    public Panel(Point[] points){
        this.points = points;
        
        setVisible(true);
        setSize(Tuning.panelWidth,Tuning.panelHeight);
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        
        int i = 0;
        int bright = 0;
        
        for(int y = 0;y<Tuning.height;y++){
            for(int x = 0;x<Tuning.width;x++){
                int value = points[i++].value;
                
                bright = ( value*250 )/Tuning.peek;
                if( bright<0 )   { bright = -bright;  }
                if( bright>250 ) { bright = 250;      }
                
                // антиматерии
                if(value>0)  { g.setColor(new Color(0,bright,bright));   }
                if(value<0)  { g.setColor(new Color(bright,bright,bright));   }
                // небо
                if(value==0) { g.setColor(new Color(0,0,250)); }
                
                g.fillRect(x*stepWidth,y*stepHeight,stepWidth,stepHeight);
            }    
        }
   
    }
    
}
         
        
    
    

