/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

public class Snake {
    public int direction = 3;
    public Point point;
    public int length = 7;
    public boolean life = true;
    
    public Snake(Point point){
        this.point = point;
        point.valueSnake = length;
    } 
    
    private void move(){
        point = point.points[direction];
        if(point.valueSnake>0){ 
            life = false; 
            point.valueSnake = 0;
        }else{
            point.valueSnake = length;
        }
    }
    
    private void ingestion(){
        if(point.valueApple>0){
            length++;
            point.valueApple = length - 1;
        }     
    }

    void process() {
        if(life){
            move();
            ingestion();
        }
    }
    
    
}
