/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package serialization;
import java.io.*;

public class Serialization {
   
   public void output(Object obj,String s) throws IOException{
        FileOutputStream f = new FileOutputStream(s);
        ObjectOutputStream out = new ObjectOutputStream(f);
        out.writeObject(obj);
        out.close();
        f.close();
        
   }
    
   public Object input(String s) throws Exception{
        Object obj = null; 
       
        FileInputStream f = new FileInputStream(s);
        ObjectInputStream in = new ObjectInputStream(f);
        obj = in.readObject();
        in.close();
        f.close();
        
        return obj;
   } 
   
    
}
