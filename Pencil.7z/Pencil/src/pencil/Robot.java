/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pencil;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class Robot {
    Graphics2D  g;
    boolean finish;
    
    public Robot(Graphics g,Point point){
        this.g = (Graphics2D)g;
        this.g.setStroke(new BasicStroke(6.0f));
        
        recursion(new Point(0,0,null),point);
    }
    
    void recursion(Point pBefore,Point p){
        if(p!=null){
            // оставить след
            g.setColor(Color.red);
            g.drawLine(pBefore.x*10+1+7, pBefore.y*10+1+7, p.x*10+1+7, p.y*10+1+7);
            
            // перейти в другую точку
            for(Point point:p.points){
                recursion(p,point); 
                if(finish){ return; }
            }
            
        }           
    }
    
}
