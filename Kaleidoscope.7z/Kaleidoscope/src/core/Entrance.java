/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

public class Entrance {
    public Matrix matrix;
    // dinamic
    public boolean process = true;
    public int level = 8;
    
    public Entrance(int width,int height){
        this.matrix = new Matrix(width,height).twoPlanes();
        reset(0);
    }
    
    public void reset(int value){
        for(int i=0;i<2;i++){
        for(Point point:matrix.points){ 
            point.value = level; 
            point.next.value = level;
        }
        }
        matrix.getPointCenter(0,0).value = value;
    }
    
    public void next(){
        if(level ==8) { level = 12; }
        else          { level = 8;  }
        reset(10000);
    }
    
    public String startStop(){
        process = !process; 
        if(process){ return "stop"; }
        else       { return "start"; }
    }
    
    public void process(){
        if(process){ 
            matrix.process();
        }
    }
    
}
