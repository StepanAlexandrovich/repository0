/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package core;

import helpers.Methods;
import helpers.Tuning;

public class Matrix {
    public Methods MS = new Methods();
    public Point[] points;
    public int width;
    public int height;
  
    public Matrix(int width,int height){
        this.width = width;
        this.height = height;
    }
    
    private Point[] create1Plane(int mode){
        int square = width*height;
        Point[] points = new Point[square];
        
        for(int i = 0;i<square;i++){
            points[i] = new Point();
        }
        
        for(int i = 0;i<square;i++){
            points[i].connection(points[i],0);
            points[i].connection(points[MS.ring(i-01,0,square-1)],1);
            points[i].connection(points[MS.ring(i-width,0,square-1)],2);
            points[i].connection(points[MS.ring(i+01,0,square-1)],3);
            points[i].connection(points[MS.ring(i+width,0,square-1)],4);
        }
        
        switch(mode){
            case 0: points = points;            break;
            case 1: points = addition1(points); break;
            case 2: points = addition2(points); break;
        }
       
        return points; 
    }
     
    private Point[] addition1(Point[] points){
        for(int y = 0;y<height;y++){    
            points[y*width].connection(points[(y+1)*width - 1],1);
            points[(y+1)*width - 1].connection(points[y*width],3);
        }
        return points;
    }
    
    private Point[] addition2(Point[] points){
        for(int i = 0;i<height;i++){ points[width*i].connection(points[width*i],1); }
        for(int i = 0;i<height;i++){ points[width*i + (width - 1)].connection(points[width*i + (width - 1)],3); }
        for(int i = 0;i<width;i++){ points[i].connection(points[i],2); }
        for(int i = 0;i<width;i++){ points[width*(height-1) + i].connection(points[width*(height-1) + i],4); }
        return points;
    }
    
    private Point[] create2Plane(int mode){
        Point[] points1 = create1Plane(mode);
        Point[] points2 = create1Plane(mode);
        for(int i = 0;i<points1.length;i++){
            points1[i].up = points2[i];
            points2[i].up = points1[i];
        }
        return points1;
    }
    
    public Point[] onePlane(int mode){  
        return ( points = create1Plane(mode) ); 
    }
    
    public Point[] twoPlane(int mode){  
        return ( points = create2Plane(mode) ); 
    }
            
    // helpers
    /////////////////////////////////////////
    private int twoDoneD(int x,int y){ return width*y + x; }
    /////////////////////////////////////////
    
    public Point pointOfAngle(int a,int b){
        return points[twoDoneD(a,b)];
    }
    
    public Point pointOfCenter(int a,int b){
        return points[twoDoneD(width/2+a,height/2+b)];
    }   
    
    public Point pointOfAngle(int a,int b,int value){
        points[twoDoneD(a,b)].value = value;
        return points[twoDoneD(a,b)];
    }
    
    public Point pointOfCenter(int a,int b,int value){
        points[twoDoneD(width/2+a,height/2+b)].value = value;
        return points[twoDoneD(width/2+a,height/2+b)];
    }   
}
