/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package core;

public class Matrix {
    public Point[] points;
    public int width,height,length;
  
    public Matrix(int width,int height){
        this.length = (this.width = width)*(this.height = height);
        
        points = new Point[length];
        for(int i = 0;i<length;i++){ 
            points[i] = new Point(); 
        }
        
        for(int y = 0;y<height;y++){
            for(int x = 0;x<width;x++){
                // задаём точке координаты 
                getPoint(x,y).x = x;
                getPoint(x,y).y = y;
                
                // устанавливаем связи c соседними точками 
                getPoint(x,y).points[0] = getPoint(x+1,y);
                getPoint(x,y).points[1] = getPoint(x,y+1);
                getPoint(x,y).points[2] = getPoint(x-1,y);
                getPoint(x,y).points[3] = getPoint(x,y-1);
            }
        }
         
    }
    
    public Matrix twoPlanes(){
        Point[] pointsNext = new Matrix(width,height).points;
        for(int i = 0;i<length;i++){
            points[i].next = pointsNext[i];
            pointsNext[i].next = points[i];
        }    
        return this;
    }
    
    // getPoint()
    /////////////////////////////////////////////////
    public Point getPoint(int x,int y){ 
        return points[width*border(y,0,height - 1) + border(x,0,width - 1)];
    }
     
    public Point getPointCenter(int a,int b){
        return getPoint(width/2+a,height/2+b);
    }   
    
    public int border(int vel,int min, int max){
        if(vel>max){ vel = max; }
        if(vel<min){ vel = min; }
        return vel;
    }
    //////////////////////////////////////////////////
    
    public void process(){
        for(int i = 0;i<points.length;i++){
            points[i].process();
            points[i] = points[i].next;
        }    
    }
   
}
