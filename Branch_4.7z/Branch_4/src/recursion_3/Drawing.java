/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion_3;

import java.awt.Graphics;
import java.util.Random;

public class Drawing {
    Graphics g;
    int length;
    
    public Drawing(Graphics g,int length){
        this.g = g;
        this.length = length;
        recursion(600,750,0,0);
    }
    
    void recursion(int xBefore,int yBefore,double rad,int i){ 
        int x = xBefore - (int)((Math.sin(rad)*length)/5);
        int y = yBefore - (int)((Math.cos(rad)*length)/5);
        
        g.drawLine(xBefore,yBefore,x,y);
        if(i<13){
            recursion(x,y,rad+(0.001)*length,i+1);
            recursion(x,y,rad-(0.001)*length,i+1);
        }
    }
    
}
