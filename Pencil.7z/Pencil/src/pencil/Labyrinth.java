/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pencil;

import java.util.Random;

public class Labyrinth {
        // static
    int width = 135,height = 68;
    Point[][] points = new Point[width][height];
        // dinamic
    Point point;
    Point pointStart;
    
    Labyrinth(int x,int y){
        point = new Point(x,y,null);
        points[point.x][point.y] = point; 
        
        pointStart = point;
    }
    
    public void process(){
        point = process(point); 
        points[point.x][point.y] = point;
    }
    
    Point process(Point p){ 
        if((getPoint(p.x+1,p.y))==null){ return p.points[0] = new Point(p.x+1,p.y,p); }
        if((getPoint(p.x-1,p.y))==null){ return p.points[1] = new Point(p.x-1,p.y,p); }
        if((getPoint(p.x,p.y+1))==null){ return p.points[2] = new Point(p.x,p.y+1,p); }
        if((getPoint(p.x,p.y-1))==null){ return p.points[3] = new Point(p.x,p.y-1,p); }
        
        return p.behind;
    }
    
    public Point getPoint(int x,int y){ 
        if(new Random().nextInt(4)==1)    { return new Point(0,0,null); }
        if(x>=width||y>=height||x<0||y<0) { return new Point(0,0,null); } 
        
        return points[x][y];
    }
    
}
