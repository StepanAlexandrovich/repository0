/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MyFrame extends JFrame implements ActionListener{
    private JPanel panel;
    private Drawing drawing = new Drawing();
    
    public MyFrame(){
        super("Snake");
        this.setVisible(true);
        this.setSize(600,600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.add(panel = new Panel());
        
        this.addKeyListener(new MyKeyAdapter());
        new Timer(1,this).start();
    }
    
    public static void main(String[] args) {
        new MyFrame();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        panel.repaint();
       
    }
    
    private class Panel extends JPanel{
        final int multiplication = 2 ;
        
        @Override
        public void paint(Graphics g){
            Image image = drawing.newDrawing();
            g.drawImage(image,0,0,drawing.width*multiplication,drawing.height*multiplication, null);            
        }
        
    }
    
    private class MyKeyAdapter extends KeyAdapter{
        
        @Override
        public void keyPressed(KeyEvent e){
            // snake control
            if(e.getKeyCode() == KeyEvent.VK_RIGHT) { drawing.objects.snake.direction = 1; }
            if(e.getKeyCode() == KeyEvent.VK_DOWN ) { drawing.objects.snake.direction = 2; }
            if(e.getKeyCode() == KeyEvent.VK_LEFT ) { drawing.objects.snake.direction = 3; }
            if(e.getKeyCode() == KeyEvent.VK_UP   ) { drawing.objects.snake.direction = 4; }
            
            // restart and exit
            if(e.getKeyCode() == KeyEvent.VK_ENTER) { drawing = new Drawing(); }
            if(e.getKeyCode() == KeyEvent.VK_ESCAPE){ System.exit(0);          }
        }
        
    }
    
}
