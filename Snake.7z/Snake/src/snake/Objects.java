/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

public class Objects {
    public Snake snake;
    public Apples apples;
    
    public Objects(int width,int height){
        apples = new Apples(width,height);
        snake  = new Snake (width,height,apples.matrix);
    }
    
    public void process(){
        snake.process();
        apples.process();
    }
     
}
