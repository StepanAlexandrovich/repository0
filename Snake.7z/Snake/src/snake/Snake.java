/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

public class Snake {
    public final Matrix matrix,matrixApples;
    
    private Point head;
    public int direction = 3,value = 5000;
    public boolean life = true;
   
    public Snake(int width,int height,Matrix matrixApples){
        matrix = new Matrix(width,height).twoPlanes();
        this.head = matrix.getPoint(125, 125);
  
        this.matrixApples = matrixApples;
    } 
    
    private boolean body(){
        if(head.value>0) { return true;  }
        else             { return false; }
    }
    
    private boolean apple(){
        if(matrixApples.getPoint(head.x,head.y).value>0){
            return true;
        }
        return false;
    }
    
    public void process() {
        if(life){
                // signal
            head.value = value;  
                // move
            head = head.next.points[direction];
                // elongation
            if(apple()){ value+=20; }
                // life
            life = !body();
        }
        
        matrix.process();
    }
     
}
