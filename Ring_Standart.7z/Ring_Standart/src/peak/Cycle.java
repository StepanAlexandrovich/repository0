

package peak;

import core.Button;
import gui.Frame;
import gui.Panel;
import java.util.logging.Level;
import java.util.logging.Logger;
import helpers.Methods;
import helpers.Tuning;
import serialization.WriteRead;

public class Cycle {
    public Button button = new Button();
    public Frame frame = new Frame(this);
    public WriteRead WR = new WriteRead(this);
    
    public Methods methods = new Methods();
    
    public int interval = Tuning.interval;
    public boolean suspendet = false;
    public boolean exit = false;
            
    public void cycle(){
        while(!exit){ 
            methods.sleep(interval);
            if(!suspendet){
                WR.outputInput();      
                button.process();
                frame.repaintPanel();
            }
        }  
        System.exit(0);
    }
    
    public void exit(){ exit = true; }
    
    public void startStop(){ suspendet = !suspendet; }
    
}
  
       
   