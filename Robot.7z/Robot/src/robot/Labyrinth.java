/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;

public class Labyrinth {
    // static
    int width = 50,height = 50;
    Point [][]points = new Point[width][height];
    Graphics2D g;
    
    // dinamic
    int i;
    
    public Labyrinth(Graphics g){
        this.g = (Graphics2D)g;
        this.g.setStroke(new BasicStroke(4.0f));
        
        
        recursion(0,0,0,0);
    }
    
    Point recursion(int xBefore,int yBefore,int x,int y){ 
        // отрисовать связь и занять нишу
        g.setColor(Color.GRAY);
        g.drawLine(xBefore*10+2, yBefore*10+2, x*10+2, y*10+2);
        points[x][y] = new Point(x,y);
        
        // является ли данная точка финишом
        if(++i==500){ 
            points[x][y].finish = true; 
            g.setColor(Color.green);
            g.fillOval(x*10-8+2, y*10-8+2,16,16);
        }
        
        // установка связей
        if((getPoint(x+1,y))==null){ points[x][y].connections[0] = recursion(x,y,x+1,y); }
        if((getPoint(x-1,y))==null){ points[x][y].connections[1] = recursion(x,y,x-1,y); }
        if((getPoint(x,y+1))==null){ points[x][y].connections[2] = recursion(x,y,x,y+1); }
        if((getPoint(x,y-1))==null){ points[x][y].connections[3] = recursion(x,y,x,y-1); }
        return points[x][y];
    }
    
    public Point getPoint(int x,int y){ 
        if(new Random().nextInt(4)==1)    { return new Point(0,0); }
        if(x>=width||y>=height||x<0||y<0) { return new Point(0,0); }
        return points[x][y]; 
    }
    
}
