/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyFrame extends JFrame{
    JPanel panel = new Panel();
    
    public MyFrame(){
        super("Window");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600,600);
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
        add(panel);    
    }
    
    class Panel extends JPanel{
        @Override
        public void paint(Graphics g){          
            new Robot(g,new Labyrinth(g).points[0][0]);
        }
    }
    
    public static void main(String[] args) {
        new MyFrame();
    }
    
}
