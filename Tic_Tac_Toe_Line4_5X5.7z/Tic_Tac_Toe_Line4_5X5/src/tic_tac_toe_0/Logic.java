package tic_tac_toe_0;

import javax.swing.JOptionPane;

public class Logic {
    public static int move;
    
    //// параметры
    public int width = 5,height = 5,distance = 4,depth = 12;
    private int length = width*height;
    //// игровая платформа
    private String[] array = new String[length];
    private Result result = new Result(width,height,distance);
    private boolean next;
    private String symbolPC,symbolUser;
    // счётчик  
    private Counter counter = new Counter(width,height,distance,depth);
    
    //// геттеры 
    public String result(){ return result.process(array); }
    
    private boolean write(int index,String symbol){
        if(index>=0&&array[index]==null){
            array[index] = symbol;
        }else{ return false; }
        return true;
    }
    
    public String[] resetPosition(){
        for(int i = 0;i<length;i++){ array[i] = null; }
        next = true;
        if(next){ symbolPC = "X"; symbolUser = "0"; }
        else    { symbolPC = "0"; symbolUser = "X"; }
        return array.clone();
    }
    
    public String[] process(int indexUser){
        if(next){
            int indexPC = 0;
            
            if(move==0){ indexPC = result.center(); }
            else{ indexPC = counter.process(array,symbolPC); }
            
            if(write(indexPC,symbolPC))     { next = !next; move++; }
        }else{
            if(write(indexUser,symbolUser)) { next = !next; move++; }
        } 
        return array.clone();
    } 
    
}
