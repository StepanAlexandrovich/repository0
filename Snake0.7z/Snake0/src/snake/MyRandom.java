/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snake;

/**
 *
 * @author User
 */
class MyRandom {
    public int value = 1,border = 7;
    
    public int nextInt(int value){
        return nextInt()%(value+1); 
    }
    
    public int nextInt(){
        while(true){
            value = value*2;
            border = border + 1;
            if(value>border){ 
                value = value - border;
                return value; 
            }
        }    
    }
}
