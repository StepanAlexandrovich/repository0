
// для проверок
//g.setColor(new Color(0,250,0));
//g.fillRect(0,0,this.getWidth(),this.getHeight());   

package wrapper;

import core.Entrance;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import core.Matrix;
import core.Point;

public class Drawing {
    public final int width = 201,height = 201;
    
    public final Entrance entrance = new Entrance(width,height);
    private final Point[] points = entrance.matrix.points;
    
    
    // отрисовка
    private BufferedImage image = new BufferedImage(width,height, BufferedImage.TYPE_INT_ARGB);
    public int multBright = 80,level = entrance.level;
    
    private int color(int value){
        int bright = (value - entrance.level)*multBright;
        if(bright>255) { bright = 255; }
        if(bright<000) { bright = 000; }
          
        return new Color(0,bright,bright).getRGB();
    }
    
    public Image newImage(){  
        entrance.process();
        for(Point point:points){
            image.setRGB(point.x,point.y,color(point.value));
        }  
        return image;
    }
    
}
         
        
    
    

