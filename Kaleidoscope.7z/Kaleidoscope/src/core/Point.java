
// 0 - in place; 1 - left; 2 - up; 3 - right; 4 - down;
 
package core;

public class Point {
    public int value,x,y;
    public Point[] points = new Point[4];
    public Point next;
    
    /////////////////////////////////////////////////////////   
    public void process(){
        next.value = value;
        for(Point point: points){  
            next.value+=point.value/5;
            next.value-=value/5;
        }  
    }
    /////////////////////////////////////////////////////////
}
